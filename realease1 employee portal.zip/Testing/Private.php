<!DOCTYPE html>
<?php
session_start();
if (!isset($_SESSION['isAdmin'])){
	header("Location: http://localhost/pp/loginTest.php?from=p");
	exit();
}
?>
	<html>

	<body>
		<a href="loginTest.php">Logout and go to log in page</a>

		This is the private page

	</body>
</html>
