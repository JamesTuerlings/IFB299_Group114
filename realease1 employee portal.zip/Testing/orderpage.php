<!DOCTYPE html>
<html>
	<head>
		<title> Welcome </title>
	</head>

	<body>
    Make an order
	</body>
</html>
