<ul>
  <li><a href="staffHome.php"> Home</a></li>
  <li><a href="staffSearchOrder.php"> Search order </a></li>
  <li><a href=""> Assigned deliveries </a></li>
</ul>
