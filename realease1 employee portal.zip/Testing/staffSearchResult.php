<?php

//require 'linkDB.php';


	$orderID = $_GET['orderID'];

	//check if variables are empty
	if ($orderID == ''){
    header( 'Location: http://localhost/pp/staffSearchOrder.php' ) ;
		}else{
			$input = $suburb;
			$sql = "SELECT * FROM order WHERE orderID LIKE ?";
		}

	//execute query
	$query = $pdo->prepare($sql);
	$query->execute(array($input));

	//check if query returned any rows
	if($query->rowCount() > 0){

	?>
	<table border="1" style="width:100%">
		<tr>
	     <td>Hotspot name</td>
	     <td>Address</td>
	     <td>Suburb</td>
	   </tr>

	<?php

	while($r = $query->fetch()){
		echo '<tr>';
	     echo '<td><a href="indivResult.php?name=', $r['hotspotName'], '">', $r['hotspotName'],'</a></td>';
	     echo '<td>',$r['Address'],'</td>';
	     echo '<td>',$r['Suburb'],'</td>';
	   echo '</tr>';
	 }
	 echo '</table>';

}else{
	echo 'There are no results matching: ', $name;
}
 ?>
